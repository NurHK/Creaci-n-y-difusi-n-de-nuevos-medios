


# Proyectos de Storytelling 2019

Digital Storytelling / Narraciones y creatividad en ecosistema digital 2018-19

Página con proyectos publicados en la Web http://utopolis.ugr.es/media/HRUN/ 

## Historias H - Hackeando el sistema 

Proyectos realizados: 

- [Nomapaul](https://github.com/Nomapaul/storytelling/blob/master/2019/H2_NOMAPAUL.md) 
- [Kira del grupo Hack010101er](https://github.com/Hack010101er/storytelling/blob/master/2019/H1.md) :star: :star:
- [Hackvelina](https://github.com/palaferia/storytelling/blob/master/2019/Plantilla.md) :star:


## Historia R - Robot & IA 

- [Familia Robot](https://github.com/FamiliaRobot/storytelling/blob/master/2019/Plantillla-proyecto.md)
- [Bowiessey](https://github.com/Bowiessey/storytelling)
- [Buelago Wall-T](https://github.com/buegalo/storytelling/blob/master/2019/Plantillla-proyecto.md) :star: :star: :star:
- [Melomanobot](https://github.com/filipdlp/MelomanobotR3)

## Historia U - mUltiversos: universos paralelos

- [Distopic](https://github.com/Distopic/storytelling) 
- [Kate de LMJ11](https://github.com/LMJ11/storytelling) :star: :star:


## Historia N - Neolenguas 

- [Riobaria](https://github.com/Riobaria/storytelling)



![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/CC-BY-SA-Andere_Wikis_%28v%29.svg/200px-CC-BY-SA-Andere_Wikis_%28v%29.svg.png)

Mayo 2019 

[Creacion y Difusión de Nuevos Contenidos Audiovisuales](http://utopolis.ugr.es/medialab)

[Facultad de Comunicación y Documentación](http://fcd.ugr.es)

Universidad de Granada
