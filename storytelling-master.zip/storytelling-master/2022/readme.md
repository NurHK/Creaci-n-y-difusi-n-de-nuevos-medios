
# Proyectos de Storytelling 2022

Digital Storytelling / Narraciones y creatividad en ecosistema digital 2021-22

Página con proyectos publicados en la Web http://utopolis.ugr.es/media/HRUN/ 

## Historias Ficción/Cyberpunk

- (4) Rebechan/Magicchan :octocat: https://github.com/gonzalomao/Magic-Chan_22
- (6) Lexi :octocat: https://github.com/martajulian/ProyectoMango_22
- (7) Barnie el jardinero :octocat: https://github.com/Jube-san/De-tos-en-tos
- (8) El Mar Blanco :octocat: https://github.com/Andrewmendo/storytelling 
- (11) er Carlillos  :octocat: https://github.com/evasola00/ElKebabTrascendental_22


## Historias Reality (tribus urbanas) 

- (1) Crónicas de un gótico indignado :octocat:  https://github.com/BeaFM/Cronicas-de-un-gotico-indignado_22
- (2) La falsa de Angeles :octocat: https://github.com/ClaraMolina00/La-falsa-de-Angeles_22
- (3) Rocío Salud Mental :octocat: https://github.com/albalinares20000/Rocio_salud_mental_22 
- (9) Eduardo Falillo :octocat:
- (14) El Rastro :octocat: https://github.com/ne0samu/EL_RASTRO_GRUPO14


## Historias Comic (animados) 

- (5) Zeus :octocat: 
- (10) A color full Show :octocat: https://github.com/MissyArt/Colourful-Show_22
- (13) eConejo Adventures :octocat: https://github.com/ToVegaBerLozanoAl/storytelling
- (12) Soñar es gratis :octocat:





-----



![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/CC-BY-SA-Andere_Wikis_%28v%29.svg/200px-CC-BY-SA-Andere_Wikis_%28v%29.svg.png)

Mayo 2022 

[Creacion y Difusión de Nuevos Contenidos Audiovisuales](http://utopolis.ugr.es/medialab)

[Facultad de Comunicación y Documentación](http://fcd.ugr.es)

Universidad de Granada
