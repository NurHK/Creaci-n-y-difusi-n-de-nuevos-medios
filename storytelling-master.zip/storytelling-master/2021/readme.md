

# Proyectos de Storytelling 2021

Digital Storytelling / Narraciones y creatividad en ecosistema digital 2020-21

Página con proyectos publicados en la Web http://utopolis.ugr.es/media/HRUN/ 

## Historias Scify  (Cyberpunk)

- Rune (SEVEN) :octocat: https://github.com/LoryLittle/Rune/blob/main/README.md

- ANATOLI SPUTNIK (GranaSlav) :octocat:

- Lilith (Los Panas) :octocat:  https://github.com/jtroco/Lilith-Los-Panas-

- kB-9 (CAVSQUAD) https://github.com/robertorantes/storytelling_21

- Astarte (Coven) :octocat: https://github.com/pmprados/storytelling_21

## Historias Reality (tribus urbanas) 

- Dolores (Los Sicues) :octocat: https://github.com/celiaalive/LosSicues_Dolores
- Roberto, el reportero directo (The Last Fake) :octocat: https://github.com/joosecarlos73/Roberto_reporterodirecto
- Joaquín el del Betis (CAV-Betis) :octocat: https://github.com/miguelrojeda/storytelling_21
- Cecilio G (LORAZEPANES) :octocat: 


### Productos

- Juego con los personajes en Arcweave: [Asesinato en BBAA](https://arcweave.com/app#/project/zr63kn26ZR)  
- Teaser de personajes https://github.com/mgea/storytelling_21/blob/master/2021/Pract2B21_Teaser.pdf  en [Protopie](https://www.protopie.io)   (es necesario descargar [APK de protopie](https://play.google.com/store/apps/details?id=io.protopie.companion&hl=en_US&gl=US) 

-----



![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/CC-BY-SA-Andere_Wikis_%28v%29.svg/200px-CC-BY-SA-Andere_Wikis_%28v%29.svg.png)

Mayo 2021 

[Creacion y Difusión de Nuevos Contenidos Audiovisuales](http://utopolis.ugr.es/medialab)

[Facultad de Comunicación y Documentación](http://fcd.ugr.es)

Universidad de Granada
