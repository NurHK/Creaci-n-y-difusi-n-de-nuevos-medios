Equipo: MeriendaCena. 

Proyecto **Andrea** 

Proyecto:  En una nueva sociedad cuyo gobierno es autoritario, el sistema penitenciario ha desarrollado un software de reinserción, donde los presos están conectados. A través de este software, viven en una sociedad utópica en la que existe una visión idealizada tanto de la sociedad como de ellos mismos. Debido a la creación de este software, el sistema ya no se basa en la reinserción en el mundo exterior.

- Contexto: futuro cercano

- Personaje: un individuo (no es ni hombre ni mujer) que ha sido encarcelado injustamente por un delito de homicidio

- Historia: el sistema penitenciario ha desarrollado un software donde los presos viven en una sociedad utópica en la que existe una visión idealizada tanto de la sociedad como de ellos mismos. Gracias a este software, el sistema penitenciario ya no se basa en la reinserción.

- Conflicto: este individuo intenta demostrar su inociencia en esta sociedad utópica creada en el software. 

Miembros del grupo: Medusadness (Marta Ortega), Arepadequeso (Rubén), Mericoke (Corina Ferrer), Dulcedeleche (Constanza Muñoz)

- ChatBot:  Andrea005 http://t.me/andrea005d_bot  (deleted)

- Banner:  http://utopolis.ugr.es/media/HRUN/U/Andrea005D/banner/index.html

- Storytelling: http://utopolis.ugr.es/media/HRUN/U/Andrea005D/Andrea005D-1.0-pc.zip

- Storytelling: http://utopolis.ugr.es/media/HRUN/U/Andrea005D/Andrea005D-1.0-mac.zip
- Storytelling: http://utopolis.ugr.es/media/HRUN/U/Andrea005D/Andrea005D-Android.apk
