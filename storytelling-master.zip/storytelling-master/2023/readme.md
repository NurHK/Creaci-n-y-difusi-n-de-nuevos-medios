
# Proyectos de Storytelling 2023

Digital Storytelling / Narraciones y creatividad en ecosistema digital 2022-23


## Historias Ficción/Cyberpunk

- (2) Ónyx	[https://github.com/ZairaV/storytelling](https://github.com/ZairaV/storytelling/blob/master/proyecto(plantilla).md) 
  * https://cloud.protopie.io/p/44f4eac019ff803433ddd515
  * https://arcweave.com/app/project/1M62axGEwr?board=630fdb8a-48d6-473e-9974-2460f7eb2b41&scale=0.444445&coords=-10178.3,-9950.7
  * :octocat: https://zairav.github.io/onyxcyberhood/


- (3) La abuelita Dorothea	https://github.com/norahdez/storytelling/blob/master/proyecto(New%20Youth).md
  * https://cloud.protopie.io/p/9942a4d8d25dcd2f82783683
  * https://arcweave.com/app/project/9WErnDyEYk/play


- (5) Shak 2-22	[https://github.com/julsbana/storytelling](https://github.com/julsbana/storytelling/blob/master/proyecto.md)
  * https://cloud.protopie.io/p/b68a2b71fa389eeb3bf656b8	
  * https://arcweave.com/app/project/vVlj3yQEgq/play    

## Historias Reality (tribus urbanas) 

- (1) Dante Elegante	https://github.com/ainhoamaperez/storytelling
  * https://cloud.protopie.io/p/e7ba4fa7c75ca5bbf6a82ecd	
  * https://arcweave.com/app/project/25lbqym0D4 

- (9) Abril	https://github.com/belenchuu01/storytelling
  * https://arcweave.com/app/project/4OlzDY46qP/play
  * https://cloud.protopie.io/p/2b43e0791884e59bbaafb30c
  * :octocat: https://belenchuu01.github.io


## Historias Comic (animados) 

- (4) LOLALOLITA	https://github.com/alexxiapav/storytelling (https://github.com/alexxiapav/storytelling/blob/master/proyecto%234.md)
  * https://cloud.protopie.io/p/6ea6d7b206054950590f620b
  * https://arcweave.com/app/project/omE74KD6RN


- (6) Luca el zapato izquierdo	https://github.com/LucaIzquierdo/storytelling
  * https://cloud.protopie.io/p/27af2f21e48243ec0eb75e25
  * https://arcweave.com/app/project/qzEe93OEeL?board=630fdb8a-48d6-473e-9974-2460f7eb2 b41&scale=0


- (8)	Andréh Boquerón	[https://github.com/sakiatun/storytelling](https://github.com/sakiatun/storytelling/blob/master/proyecto.md)
  * https://cloud.protopie.io/p/993b54b978dc525617bb870f
  * https://arcweave.com/app/project/kWloRBR0qd
  




### Enlace a **[presentaciones](https://github.com/mgea/storytelling/blob/master/2023/presentaciones.md)** y resultados 




-----
![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/CC-BY-SA-Andere_Wikis_%28v%29.svg/200px-CC-BY-SA-Andere_Wikis_%28v%29.svg.png)

Junio 2023 

[Creacion y Difusión de Nuevos Contenidos Audiovisuales](http://utopolis.ugr.es/medialab)

[Facultad de Comunicación y Documentación](http://fcd.ugr.es)

Universidad de Granada
