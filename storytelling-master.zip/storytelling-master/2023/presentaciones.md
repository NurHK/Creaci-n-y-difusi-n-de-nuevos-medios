# Presentaciones 2023 (junio 2023)


### Dante elegante 



![Dante](https://github.com/mgea/storytelling/blob/master/2023/dante.jpg)

### Onyx 

![Onyx](https://github.com/mgea/storytelling/blob/master/2023/onyx.jpg)

:octocat: https://zairav.github.io/onyxcyberhood/



### Shak 

![shak](https://github.com/mgea/storytelling/blob/master/2023/shak.jpg)


### Abril 

![Abril](https://github.com/mgea/storytelling/blob/master/2023/abril.jpg)



### Dorothea 

![Dorothea](https://github.com/mgea/storytelling/blob/master/2023/dorohtea.jpg)

playgroundAI - generar fondos 


### Lola Lolita 

![lola](https://github.com/mgea/storytelling/blob/master/2023/lola.jpg)


### Luca 

![luca](https://github.com/mgea/storytelling/blob/master/2023/luca.jpg)

### Andrei 

![andrei](https://github.com/mgea/storytelling/blob/master/2023/andrei.jpg)



## Resultados 

![valroaciones](https://github.com/mgea/storytelling/blob/master/2023/valora.png)

![clase](https://github.com/mgea/storytelling/blob/master/2023/claseAll.jpg)









